/**
 * YUI Test Framework
 * @module yuitest
 */

/**
 * The root namespace for YUI Test.
 * @class YUITest
 * @static
 */

var YUITest = {
    version: "@VERSION@"
};
